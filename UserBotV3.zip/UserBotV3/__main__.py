import signal
import tornado.ioloop
import tornado.platform.asyncio
import asyncio
from pyrogram import Client
from rich.console import Console
from rich.panel import Panel
from rich.spinner import Spinner
from rich.text import Text
from rich.table import Table
from rich.progress import Progress
from datetime import datetime
from PyroUbot import bot, Ubot, get_userbots, remove_ubot, loadPlugins, installPeer, expiredUserbots, bash

# Inisialisasi rich console
console = Console()

# ASCII Art untuk Tuan99 dan JagoannyaBot
ASCII_ART = """
   _____ _          
  |  __ (_)_       
  | |__  _| | ___  
  |  __|_| |/ __| 
  | |   _| | (__  
  |_|  (_) |_|___|

    JAGOANNYABOT
"""

def print_header():
    console.print(
        Panel(
            Text(ASCII_ART, style="bold green", justify="center"),
            title="[bold blue]Tuan99's JagoannyaBot[/bold blue]",
            subtitle="[cyan]Powered by PyroUbot[/cyan]",
            border_style="yellow"
        )
    )

def log_info(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    console.print(f"[dim white][{timestamp}][/dim white] [bold cyan][INFO][/bold cyan] {message}")

def log_success(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    console.print(f"[dim white][{timestamp}][/dim white] [bold green][SUCCESS][/bold green] {message}")

def log_error(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    console.print(f"[dim white][{timestamp}][/dim white] [bold red][ERROR][/bold red] {message}")

async def shutdown(signal, loop):
    log_info(f"Received exit signal {signal.name}...")
    tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]

    with console.status("[bold yellow]Cancelling outstanding tasks...", spinner="dots"):
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
    
    log_info("All tasks cancelled, stopping loop...")
    loop.stop()
    log_success("Tuan99's JagoannyaBot has shut down gracefully!")

async def main():
    # Tampilkan header saat startup
    print_header()
    log_info("Starting Tuan99's JagoannyaBot...")

    # Animasi loading saat bot start
    with console.status("[bold green]Initializing JagoannyaBot...", spinner="arc"):
        await bot.start()
    log_success("JagoannyaBot is online! 🎉")

    # Proses userbots dengan progress bar
    try:
        userbots = await get_userbots()
    except Exception as e:
        log_error(f"Failed to load userbots: {str(e)}")
        userbots = []
    if userbots:
        log_info(f"Found {len(userbots)} userbots to initialize...")
        with Progress(console=console, transient=True) as progress:
            task = progress.add_task("[cyan]Starting userbots...", total=len(userbots))
            for _ubot in userbots:
                ubot_ = Ubot(**_ubot)
                try:
                    await asyncio.wait_for(ubot_.start(), timeout=10)
                    log_success(f"Userbot {_ubot['name']} started successfully!")
                except asyncio.TimeoutError:
                    await remove_ubot(int(_ubot["name"]))
                    log_error(f"Userbot {_ubot['name']} failed to respond, removed!")
                except Exception as e:
                    await remove_ubot(int(_ubot["name"]))
                    log_error(f"Userbot {_ubot['name']} removed due to error: {str(e)}")
                progress.advance(task)
    else:
        log_info("No userbots found, skipping...")

    # Membersihkan sesi dengan animasi
    with console.status("[bold yellow]Cleaning up session files...", spinner="bouncingBall"):
        await bash("rm -rf *session*")
    log_success("Session files cleaned up!")

    # Memuat plugin dengan tabel
    log_info("Loading plugins for JagoannyaBot...")
    with console.status("[bold cyan]Installing plugins...", spinner="moon"):
        await asyncio.gather(loadPlugins(), installPeer(), expiredUserbots())
    log_success("Plugins loaded successfully!")

    # Menampilkan status akhir
    status_table = Table(title="[bold green]JagoannyaBot Status[/bold green]", show_header=False, border_style="cyan")
    status_table.add_row("Owner", "[bold yellow]Tuan99[/bold yellow]")
    status_table.add_row("Bot", "[bold blue]JagoannyaBot[/bold blue]")
    status_table.add_row("Status", "[bold green]Running[/bold green]")
    console.print(status_table)

    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()
    for s in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(
            s, lambda: asyncio.create_task(shutdown(s, loop))
        )

    try:
        log_info("JagoannyaBot is now awaiting commands... 🦾")
        await stop_event.wait()
    except asyncio.CancelledError:
        log_info("Shutdown signal received, preparing to stop...")
    finally:
        with console.status("[bold red]Stopping JagoannyaBot...", spinner="star"):
            await bot.stop()
        log_success("Tuan99's JagoannyaBot has stopped!")

if __name__ == "__main__":
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = tornado.ioloop.IOLoop.current().asyncio_loop
    try:
        loop.run_until_complete(main())
    except KeyboardInterrupt:
        log_info("Keyboard interrupt received, shutting down...")
    finally:
        loop.close()
        log_success("Event loop closed, goodbye from Tuan99's JagoannyaBot! 👋")