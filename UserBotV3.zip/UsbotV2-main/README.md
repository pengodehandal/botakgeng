<p align="center">
    <a href="https://github.com/pyrogram/pyrogram">
        <img src="https://docs.pyrogram.org/_static/pyrogram.png" alt="Pyrogram" width="128">
    </a>
    <br>
    <b>Telegram MTProto API Framework for Python</b>
    <br>
    <a href="https://pyrogram.org">
        Homepage
    </a>
    •
    <a href="https://docs.pyrogram.org">
        Documentation
    </a>
    •
    <a href="https://docs.pyrogram.org/releases">
        Releases
    </a>
    •
    <a href="https://t.me/pyrogram">
        News
    </a>
</p>

## Pyrogram
> This Pyrogram code, Recode With BY <a href="https://t.me/ketawaloidiot">Kahn</a>
___________________________________________
## Commad Installer Userbot
```
apt update && apt upgrade -y
```
```
apt install ffmpeg -y
```
```
git clone https://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@github.com/OhMyKhan/UsbotV2.git
```
```
echo "https://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@github.com" >> ~/.git-credentials
```
```
git config --global credential.helper store
```
```
cd UserbotPrem
```
```
apt -y install python3-venv; python3 -m venv venv; . venv/bin/activate; pip install -r requirements.txt 
```
```
wget -O speedtest-cli https://raw.githubusercontent.com/sivel/speedtest-cli/master/speedtest.py && chmod +x speedtest-cli
```
```
screen python3 -m PyroUbot
```
# UsbotV2
