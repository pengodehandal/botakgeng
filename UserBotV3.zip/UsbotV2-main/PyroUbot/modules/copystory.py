from pyrogram import Client
from pyrogram.errors import FloodWait
from pyrogram.types import Story
from PyroUbot import *  # Import decorator @PY.UBOT
import re

# Fungsi untuk menyalin story
@PY.UBOT("copystory")
async def copy_story(client: Client, message):
    try:
        # Mendapatkan link atau ID story dari pesan yang diterima
        if message.reply_to_message:
            link = message.reply_to_message.text
        else:
            link = message.text.split(" ", 1)[1]  # Mendapatkan link dari pesan

        # Cek apakah link valid
        if not link.startswith("https://t.me/") or "/s/" not in link:
            await message.reply("❌ Link story tidak valid!")
            return

        # Ekstrak username dan story_id dari link
        match = re.match(r'https://t.me/([^/]+)/s/(\d+)', link)
        
        if match:
            username = match.group(1)
            story_id = int(match.group(2))  # ID story harus dalam bentuk integer
            chat_id = username  # Menggunakan username sebagai chat_id
        else:
            await message.reply("❌ Link story tidak valid!")
            return

        # Mengambil stories berdasarkan ID
        stories = await client.get_stories(chat_id, story_id)

        if isinstance(stories, Story):  # Jika lebih dari satu story
            for story in stories:
                # Cek jika media berupa foto/vidio
                if story.media:
                    # Cek apakah media adalah foto atau video
                    if isinstance(story.media, pyrogram.types.Photo):
                        # Kirim foto ke chat tujuan
                        await client.send_photo(message.chat.id, story.media.file_id, caption=story.caption)
                    elif isinstance(story.media, pyrogram.types.Video):
                        # Kirim video ke chat tujuan
                        await client.send_video(message.chat.id, story.media.file_id, caption=story.caption)
                    else:
                        print("Unsupported media type")
            await message.reply("✅ Story berhasil disalin!")
        else:
            await message.reply("❌ Tidak ada story yang ditemukan.")

    except FloodWait as e:
        await message.reply(f"⏳ Flood wait: Tunggu {e.x} detik sebelum mencoba lagi.")
    except Exception as e:
        await message.reply(f"❌ Terjadi error: {str(e)}")

