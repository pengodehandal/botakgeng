__MODULE__ = "ʙʟᴀᴄᴋʟɪꜱᴛ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Blacklist

perintah : <code>{0}addbl</code>
    memasukan group ke daftar blacklist

perintah : <code>{0}unbl</code>
    menghapus group dari daftar blacklist

perintah : <code>{0}rallbl</code>
    menghapus semua daftar blacklist group

perintah : <code>{0}listbl</code>
    memeriksa daftar blacklist group</b></blockquote>
"""
