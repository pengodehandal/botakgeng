import asyncio
import json
import math
import os
import requests
from datetime import timedelta
from time import time
from functools import partial
from asyncio import get_event_loop
from urllib.parse import urlparse

import wget
from bs4 import BeautifulSoup
from yt_dlp import YoutubeDL
from youtubesearchpython import VideosSearch

from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.errors import FloodWait, MessageNotModified, ChatAdminRequired, UserBannedInChannel
from pyrogram.enums import ChatType

from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream, AudioQuality, VideoQuality
from pytgcalls.types.calls import Call
from pytgcalls.exceptions import NoActiveGroupCall, NotInCallError

from PyroUbot import *

@PY.UBOT("syt")
@PY.TOP_CMD
async def playyt_cmd(client, message):
    if len(message.command) < 2:
        return await message.reply_text(
            "❌ <b>ᴀᴜᴅɪᴏ ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ,</b>\nᴍᴏʜᴏɴ ᴍᴀsᴜᴋᴀɴ ᴊᴜᴅᴜʟ ᴠɪᴅᴇᴏ ᴅᴇɴɢᴀɴ ʙᴇɴᴀʀ."
        )

    infomsg = await message.reply_text("<b>🔍 ᴘᴇɴᴄᴀʀɪᴀɴ...</b>", quote=False)

    try:
        search = VideosSearch(message.text.split(None, 1)[1], limit=1).result()["result"][0]
        link = f"https://youtu.be/{search['id']}"
    except Exception as error:
        return await infomsg.edit(f"<b>🔍 ᴘᴇɴᴄᴀʀɪᴀɴ...\n\n{error}</b>")

    chat_id = message.chat.id
    a_calls = await client.call_py.calls
    if_chat = a_calls.get(chat_id)
    if if_chat:
        return await msg.edit_text("<b>Already playing a video in the call chat!</b>")
    try:
        (
            file_name,
            title,
            url,
            duration,
            views,
            channel,
            thumb,
            data_ytp,
        ) = await YoutubeDownload(link, as_video=False)
    except Exception as error:
        return await infomsg.edit(f"<b>📥 ᴅᴏᴡɴʟᴏᴀᴅᴇʀ...\n\n{error}</b>")

    # Unduh thumbnail
    thumbnail_path = f"{search['id']}.jpg"
    wget.download(thumb, thumbnail_path)
    
    await client.call_py.play(
            chat_id,
            MediaStream(
                file_name,
                video_flags=MediaStream.Flags.IGNORE,
                audio_parameters=AudioQuality.STUDIO,
        )
            )
   
    # Kirim thumbnail sebagai foto
    await client.send_photo(
        message.chat.id,
        photo=thumbnail_path,
        caption=data_ytp.format(
            ": sᴜᴄᴄᴇs ᴘʟᴀʏɪɴɢ",
            title,
            timedelta(seconds=duration),
            views,
            channel,
            url,
            bot.me.mention,
        ),
        reply_to_message_id=message.id,
    )

    await infomsg.delete()

    # Hapus file yang telah diunduh
    for files in (thumbnail_path, file_name):
        if files and os.path.exists(files):
            os.remove(files)

@PY.UBOT("vyt")
@PY.TOP_CMD
async def vyt_cmd(client, message):
    if len(message.command) < 2:
        return await message.reply_text(
            "❌ <b>ᴀᴜᴅɪᴏ ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ,</b>\nᴍᴏʜᴏɴ ᴍᴀsᴜᴋᴀɴ ᴊᴜᴅᴜʟ ᴠɪᴅᴇᴏ ᴅᴇɴɢᴀɴ ʙᴇɴᴀʀ."
        )

    infomsg = await message.reply_text("<b>🔍 ᴘᴇɴᴄᴀʀɪᴀɴ...</b>", quote=False)

    try:
        search = VideosSearch(message.text.split(None, 1)[1], limit=1).result()["result"][0]
        link = f"https://youtu.be/{search['id']}"
    except Exception as error:
        return await infomsg.edit(f"<b>🔍 ᴘᴇɴᴄᴀʀɪᴀɴ...\n\n{error}</b>")

    chat_id = message.chat.id
    active_calls = await client.call_py.calls
    if chat_id in active_calls:
        return await infomsg.edit_text("<b>🚫 Sedang ada musik yang diputar di grup ini!</b>")

    try:
        (
            file_name,
            title,
            url,
            duration,
            views,
            channel,
            thumb,
            data_ytp,
        ) = await YoutubeDownload(link, as_video=True)
    except Exception as error:
        return await infomsg.edit(f"<b>📥 ᴅᴏᴡɴʟᴏᴀᴅᴇʀ...\n\n{error}</b>")

    # Unduh thumbnail
    thumbnail_path = f"{search['id']}.jpg"
    wget.download(thumb, thumbnail_path)

    # Memutar audio di obrolan suara grup
    try:
        await client.call_py.play(
            chat_id,
            MediaStream(
                file_name,  # Gunakan URL streaming langsung agar tidak perlu mendownload file
                AudioQuality.HIGH,
                VideoQuality.HD_720p,
                ytdlp_parameters='--cookies cookies.txt'
            ),
        )
    except Exception as error:
        return await infomsg.edit(f"<b>🚫 Gagal Memutar Musik:</b>\n{error}")

    # Kirim thumbnail sebagai foto
    await client.send_photo(
        message.chat.id,
        photo=thumbnail_path,
        caption=data_ytp.format(
            ": sᴜᴄᴄᴇs ᴘʟᴀʏɪɴɢ",
            title,
            timedelta(seconds=duration),
            views,
            channel,
            url,
            bot.me.mention,
        ),
        reply_to_message_id=message.id,
    )
    
    await infomsg.delete()
    
    # Hapus file yang telah diunduh
    for files in (thumbnail_path, file_name):
        if files and os.path.exists(files):
            os.remove(files)

@PY.UBOT("end")
@PY.TOP_CMD
@PY.GROUP
async def leave_vc(client, message):
    brhsl = await EMO.BERHASIL(client)
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    try:
        mex = await message.reply(f"{prs}proccesing...")
        await client.call_py.leave_call(message.chat.id)
        await mex.edit(f"{brhsl}berhasil")
    except NotInCallError:
        await mex.edit(f"{ggl}belum bergabung ke voice chat")
    except UserBannedInChannel:
        pass
    except Exception as e:
        print(e)

@PY.UBOT("pause")
@PY.TOP_CMD
@PY.GROUP
async def pause_vc(client, message):
    brhsl = await EMO.BERHASIL(client)
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    chat_id = message.chat.id

    try:
        msg = await message.reply(f"{prs} Proses")
        await client.call_py.pause_stream(chat_id)  # Perbaiki metode pause sesuai library yang digunakan
        await msg.edit(f"{brhsl} Sukses")
    except Exception as e:
        await msg.edit(f"{ggl} Gagal: {e}")
