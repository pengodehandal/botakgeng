__MODULE__ = "ᴠᴄᴛᴏᴏʟꜱ"
__HELP__ = """
<blockquote>Bantuan Untuk VcTools

perintah : <code>{0}jvc</code>
    untuk bergabung ke voice chat group

perintah : <code>{0}lvc</code>
    untuk meninggalkan dari voice chat group
"""

from pyrogram import Client, filters
from pyrogram.types import Message
from asyncio import get_event_loop
from functools import partial
from yt_dlp import YoutubeDL
from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream
from pytgcalls.types.calls import Call
from pyrogram.errors import ChatAdminRequired, UserBannedInChannel
from pytgcalls.exceptions import NotInCallError
from youtubesearchpython import VideosSearch
import os
import wget
import math
from datetime import timedelta
from time import time
from pyrogram.errors import FloodWait, MessageNotModified
from pyrogram.enums import ChatType
from PyroUbot import *

if not os.path.exists("downloads"):
    os.makedirs("downloads")

@PY.UBOT("playvc")
@PY.TOP_CMD
@PY.GROUP
async def play_vc(client, message):
    brhsl = await EMO.BERHASIL(client)
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        if len(message.command) < 2:
            await message.reply(f"{ggl} Harap masukkan judul atau URL video YouTube.")
            return

        query = " ".join(message.command[1:])
        mex = await message.reply(f"{prs} Mencari video...")
        search = VideosSearch(query, limit=1)
        result = search.result()["result"]
        
        if not result:
            await mex.edit(f"{ggl} Video tidak ditemukan!")
            return
        
        video_url = result[0]["link"]
        video_title = result[0]["title"]

        await mex.edit(f"{prs} Mengunduh **{video_title}**...")
        ydl_opts = {
            "format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]",
            "outtmpl": "downloads/%(title)s.%(ext)s"
        }

        loop = get_event_loop()
        with YoutubeDL(ydl_opts) as ydl:
            video_info = await loop.run_in_executor(None, partial(ydl.extract_info, video_url))
            video_path = ydl.prepare_filename(video_info)

        await mex.edit(f"{prs} Memutar video di voice chat...")
        await client.call_py.join_call(message.chat.id)
        await client.call_py.play(message.chat.id, video_path)
        await mex.edit(f"{brhsl} **Berhasil memutar {video_title} di voice chat!**")

    except Exception as e:
        await mex.edit(f"{ggl} Terjadi kesalahan: {str(e)}")


@PY.UBOT("lvc")
@PY.TOP_CMD
@PY.GROUP
async def leave_vc(client, message):
    brhsl = await EMO.BERHASIL(client)
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    try:
        mex = await message.reply(f"{prs}proccesing...")
        await client.call_py.leave_call(message.chat.id)
        await mex.edit(f"{brhsl}berhasil turun dari obrolan suara")
    except NotInCallError:
        await mex.edit(f"{ggl}belum bergabung ke voice chat")
    except UserBannedInChannel:
        pass
    except Exception as e:
        print(e)

@PY.UBOT("jvc")
@PY.TOP_CMD
@PY.GROUP
async def join_vc(client, message):
    brhsl = await EMO.BERHASIL(client)
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    try:
        mex = await message.reply(f"{prs}proccesing...")
        await client.call_py.play(message.chat.id)
        await client.call_py.mute_stream(message.chat.id)
        await mex.edit(f"{brhsl}**berhasil join ke voice chat**")        
    except ChatAdminRequired:
        await mex.edit(f"{ggl}**maaf tidak bisa join vc**")
    except UserBannedInChannel:
        pass
    except Exception as e:
        print(e)
