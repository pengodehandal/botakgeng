from pyrogram import types
from PyroUbot import *  # Sesuaikan dengan struktur proyek kamu

__MODULE__ = "mute info"
__HELP__ = "Menampilkan daftar grup yang membisukan bot.\n\n🔹 <code>/muted_groups</code> - Cek daftar grup yang membisukan bot."

@PY.UBOT("muted")
async def list_muted_groups(c: Client, m: Message):
    tit = await m.reply("🔍 <b>Memeriksa grup yang membisukan bot...</b>", quote=True)

    muted_groups = []

    async for y in c.get_dialogs():
        if y.chat.type.value in ["supergroup", "group"]:
            try:
                mem = await c.get_chat_member(y.chat.id, c.me.id)
                # Mengecek apakah bot tidak bisa mengirim pesan (mute)
                if not getattr(mem, "can_send_messages", True):
                    muted_groups.append(f"📌 <code>{y.chat.title}</code>")
            except Exception:
                pass

    # Format hasil dengan lebih menarik
    if muted_groups:
        _text = (
            "📢 <b><u>DAFTAR GRUP YANG MEMBISUKAN BOT</u></b>\n\n"
            + "\n".join(muted_groups)
            + f"\n\n❗ <b>Total Grup yang Membisukan:</b> <code>{len(muted_groups)}</code>"
        )
    else:
        _text = "✅ <b>Bot tidak dibisukan di grup mana pun!</b>"

    await tit.edit(_text)
