from os import getenv
from typing import List

from pykeyboard import InlineKeyboard
from pyrogram.enums import ChatType
from pyrogram.errors import ChatAdminRequired, ChatWriteForbidden, UserNotParticipant
from pyrogram.types import InlineKeyboardButton

from PyroUbot import *

# Ambil daftar channel/grup yang harus disubscribe dari environment variable
FORCE_SUBSCRIBE = list(
    map(
        int,
        getenv(
            "FORCE_SUBSCRIBE", "-1002025913659 -1002390191199"
        ).split(),
    )
)

# Decorator untuk mengecek apakah user sudah subscribe
def MULTI_SUBSCRIBE(func):
    async def subscribe(client, message):
        user_id = message.from_user.id
        user_name = f"{message.from_user.first_name} {message.from_user.last_name or ''}"
        rpk = f"<a href=tg://user?id={user_id}>{user_name}</a>"

        if not FORCE_SUBSCRIBE:
            return await func(client, message)  # Jika tidak ada channel yang diatur, langsung lanjut

        try:
            for chat_id in FORCE_SUBSCRIBE:
                try:
                    await bot.get_chat_member(chat_id, user_id)  # Cek apakah user sudah join
                except UserNotParticipant:
                    buttons = InlineKeyboard(row_width=2)
                    keyboard: List[InlineKeyboardButton] = []

                    for chat_id in FORCE_SUBSCRIBE:
                        get = await bot.get_chat(chat_id)
                        FSubLink = get.invite_link  # Ambil link undangan
                        if get.type in {ChatType.GROUP, ChatType.SUPERGROUP}:
                            FSubName = "• Join Group •"
                        else:
                            FSubName = "• Join Channel •"
                        keyboard.append(InlineKeyboardButton(text=FSubName, url=FSubLink))

                    buttons.add(*keyboard)

                    try:
                        await message.reply(
                            f"""
<blockquote><b>🙋🏻‍♂️ Halo {rpk}, Apa kabar?

💡 Untuk menggunakan bot ini, Anda harus join dulu ke grup/channel.

✅ Jika sudah join, silakan kirim ulang perintah: {message.text}</b></blockquote>
""",
                            disable_web_page_preview=True,
                            reply_markup=buttons,
                        )
                        await message.stop_propagation()  # Hentikan proses command
                    except ChatWriteForbidden:
                        pass
                    return  # Hentikan eksekusi selanjutnya
        except ChatAdminRequired:
            await message.reply(f"Saya bukan admin di salah satu grup/channel yang diatur!")

        return await func(client, message)  # Jika sudah subscribe, lanjut eksekusi command

    return subscribe
