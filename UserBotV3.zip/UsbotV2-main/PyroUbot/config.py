import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "20"))

DEVS = list(map(int, os.getenv("DEVS", "6241861936").split()))

API_ID = int(os.getenv("API_ID", "20671676"))

API_HASH = os.getenv("API_HASH", "9a50bcdd038a9d1dd06808cf56b03915")

BOT_TOKEN = os.getenv("BOT_TOKEN", "7570003100:AAFDztT1vLq5u_rc3uIoAOvRyPdaTuChNS4")

OWNER_ID = int(os.getenv("OWNER_ID", "6241861936"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002399953106").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://ajakahn1:992A79uh57QrPUMs@cluster0.8eenc.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "6241861936"))

USER_GROUP = os.getenv("USER_GROUP", "@kahnubot")
